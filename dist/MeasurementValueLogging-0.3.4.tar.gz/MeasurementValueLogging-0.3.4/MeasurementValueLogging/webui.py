import webui_data.routes

webui.routes.main()